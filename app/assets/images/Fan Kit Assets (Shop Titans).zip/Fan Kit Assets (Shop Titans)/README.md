# Shop Titans - Fan Kit
This fan kit is provided by Kabam Montreal for fans of Shop Titans to use for Shop Titans related projects. 
You may not redistribute any of these assets or monetize any project using these assets without direct permission from Kabam Montreal. 

# Changelog

# June 16th, 2024
  * Added asset for Platinum Strudel.
  * Added asset for Ironclad Grapple.
  * Added assets for Anniversary Offer packs.

# June 11th, 2024
  * Added assets for 17.0 Splash Screen (5th Anniversary).
  * Added assets for Shop Titans Mega and Superior Packs.
  * Added assets for Artifact blueprint types.
  * Added assets for Minor and Greater Artifact chests and keys.
  * Added assets for Artifact components.
  * Added assets for Artifact blueprints.
  * Added assets for Level Loops.
  * Added asset for Seed of Merit.
  * Added assets for Supreme Moonstones and Runestone.
  * Added assets for Tier 14 elements and spirits.

# May 28th, 2024
  * Added assets for Buggy Beetle Mega and Superior Packs.

# May 14th, 2024
  * Added assets for Cursed King Mega and Superior Packs.
  * Added assets for Ironclad Content Pass.
  * Added asset for Platinum Winter Hat.

# May 6th, 2024
  * Added assets for Chronomancer Mega and Superior Packs.
